// codigo inicial de javascript
// rama nuevos cambios
const persona = new Object()
